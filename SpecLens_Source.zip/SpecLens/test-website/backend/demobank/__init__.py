"""DemoBank API package."""
